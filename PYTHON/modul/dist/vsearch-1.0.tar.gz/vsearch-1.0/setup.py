from setuptools import setup
setup(
    name='vsearch',
    version ='1.0',
    descrition = 'sFfAREFwer',
    py_modules=['vsearch']
)